### decript router test
# the first part takes the input from the user tells it how many routers to rotate it
encriptm = input("waht is the message you want to deccript")
lencriptm = len(encriptm)
router2 = 0
router3 = 0
while lencriptm >=25:
    lencriptm = lencriptm-25
    router2 = router2 + 1
while router2 >= 25:
    router2 = router2-25
    router3 = router3 +1

class router1:
        def __init__(self,routerout):
            self.routerin =  ["a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"]
            self.routerout = routerout
        
        def __setrouter__(self,setr):
            self.routerout = self.routerout[-setr:] + self.routerout[:-setr]
        

        def __workrouter__(self,word):
            decriptedm = ""
            for k in range(len(word)):
                self.routerout = self.routerout[-1:] + self.routerout[:-1]
                
                for l in range(len(self.routerin)):
                    if word[k] == self.routerin[l]:
                        decriptedm = decriptedm + self.routerout[l]
            return decriptedm

class routerextra:
        def __init__(self,routerout):
            self.routerin =  ["a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"]
            self.routerout = routerout
        
        def __setrouter__(self,setr,autor):
            self.routerout = self.routerout[-setr:] + self.routerout[:-setr]
            self.routerout = self.routerout[-autor:] + self.routerout[:-autor]

        def __workrouter__(self,word):
            decriptedm = ""
            for k in range(len(word)):
                for l in range(len(self.routerin)):
                    if word[k] == self.routerin[l]:
                        decriptedm = decriptedm + self.routerout[l]
            
            return decriptedm

def __refelector__(word):
    reflectin =   ["a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"]
    reflectout =  ["b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z","a"]
    reflectedmessage = ""
    for k in range(len(word)):
        for l in range(len(reflectout)):
            if word[k] == reflectout[l]:
                reflectedmessage = reflectedmessage + reflectin[l]
    return reflectedmessage 








thirdrouter = routerextra(["a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"])
thirdrouter.__setrouter__(int(input("set router to what number")),router3)
a = thirdrouter.__workrouter__(encriptm)

secondrouter = routerextra(["a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"])
secondrouter.__setrouter__(int(input("set router to what number")),router2)
b = secondrouter.__workrouter__(a)

firstrouter = router1(["a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"])
firstrouter.__setrouter__(int(input("set router to what number")))
c = firstrouter.__workrouter__(b)

d = __refelector__(c)

e = thirdrouter.__workrouter__(d)
f = secondrouter.__workrouter__(e)
g = firstrouter.__workrouter__(f)




print(a)
print(b)
print(c)
print(d)
print(e)
print(f)
print(g)
#enuop
