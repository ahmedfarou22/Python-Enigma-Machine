##### decripter

setrouter = int(input("set router to what number"))
inputt =  ["a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"]
outputt = ["a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"]
outputt = outputt[setrouter:] + outputt[:setrouter]


decriptedmessage = []
word = input("waht is the word you want to decript")

for k in range(len(word)):
    inputt = inputt[-1:] + inputt[:-1]

for i in range(len(word)):
    for l in range(len(outputt)):
        if word[i] == outputt[l]:
            decriptedmessage.append(inputt[l])
print(decriptedmessage)

