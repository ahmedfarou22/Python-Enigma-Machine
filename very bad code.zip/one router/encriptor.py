################## encripter
setrouter = int(input("set router to what number"))
inputt =  ["a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"]
outputt = ["a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"]
outputt = outputt[setrouter:] + outputt[:setrouter]
print(outputt)
encriptedmessage = []
decriptedmessage = []

word = input("waht is the word you want to encript")

for k in range(len(word)):
    outputt = outputt[1:] + outputt[:1]
    print(outputt)


for i in range(len(word)):
    for l in range(len(inputt)):
        if word[i] == inputt[l]:
            encriptedmessage.append(outputt[l])
print(encriptedmessage)
