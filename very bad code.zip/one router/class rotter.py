class router:
        def __init__(self):
            self.routerin =  ["a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"]
            self.routerout = colections.deque(["h","f","i","z","g","o","1","k","j","n","p","b","y","a","r","s","t","u","l","m","v","w","c","d","x","e"])
        
        def __workrouter__(self,x):
            if x not in self.routerin:
                print("your input is not in the ")
            else:
                for i in range(len(self.routerin)):
                    if x == self.routerin[i]:
                        print(self.routerout[i])
                        break
                self.routerout.rotate(1)
                print(self.routerout)


router1 = router()
router1.__workrouter__(input("waht is the letter you want to encript"))