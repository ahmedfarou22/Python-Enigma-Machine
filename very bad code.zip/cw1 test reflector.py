# this is the reflector // also it can be used as the plugborad but with some simple modification 

inputt =  ["a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"]
outputt = ["b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z","a"]

x = input("what is the letter you want to reflect")
if x not in inputt:
    print("your input is not in the reflector")
else:
    for i in range(len(inputt)):
        if x == inputt[i]:
            print(outputt[i])
            break
    n = int(input("how many units do you want to shift the list"))
    outputt = outputt[n:] + outputt[:n]
    print(outputt)

########### router set
setrouter = int(input("how many units do you want to shift the list"))
inputt =  ["a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"]
outputt = ["b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z","a"]
outputt = outputt[setrouter:] + outputt[:setrouter]
print(outputt)

x = input("what is the letter you want to encript")
if x not in inputt:
    print("your input is not in the router")
else:
    for i in range(len(inputt)):
        if x == inputt[i]:
            print(outputt[i])
            break
